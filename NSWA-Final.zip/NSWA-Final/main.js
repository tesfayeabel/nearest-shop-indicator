// Main entry point for Vite
import './style.css';